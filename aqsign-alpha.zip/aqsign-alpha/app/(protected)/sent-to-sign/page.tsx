import SendToSignForm from "@/components/send-to-sign-form"

export default function SentToSign() {
  return (
    <div className="p-4">
      <SendToSignForm />
    </div>
  )
}
